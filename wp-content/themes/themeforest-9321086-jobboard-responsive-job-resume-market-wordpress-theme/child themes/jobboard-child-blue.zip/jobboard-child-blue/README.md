JobBoard Child Theme
===

Custom child theme for JobBoard WordPress theme.

## JobBoard Child version 1.5.1 (Since June 9, 2015)
### Changelogs:
* `Fixed` user menu position at main header menu
* `Fixed` dashboard pagination prev/next

## JobBoard Child version 1.5.0 (Since March 22, 2016)
* Compatible with JobBoard 2.5

## JobBoard Child version 1.1.0 (Since August 27, 2015)
### Changelogs:
* `Added` theme options for resume search result page
* `Updated` form action URL resume search homepage

## JobBoard Child version 1.0.0 (Since July 30, 2015)
* Initial release
